public class Humain {
    public String nom{

    }
    public String gender{

    }
}
