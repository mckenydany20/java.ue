public class Humain {
    public String nom="danielle";
    public String gender="feminin";
    static void test(){
        System.out.println("je suis une methode de la classe humain je suis stactic");
    }
    static int n=0;
    public Humain(String n,String s){
        this.nom=n;
        this.gender=s;
    }

}
