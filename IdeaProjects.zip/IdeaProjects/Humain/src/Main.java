public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        Humain h1 = new Humain("dany","female");
        System.out.println(h1.nom);
        Humain.test();

    }
}