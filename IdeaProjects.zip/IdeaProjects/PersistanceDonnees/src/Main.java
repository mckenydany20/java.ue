import java.sql.*;

public class Main {
    public static void main(String[] args) {
        try {
            String db="ICT2";
            String user="root";
            String password="";
            String url="jdbc:mysql://localhost:3306/"+db;
// connexion à la BD
            Connection conn = DriverManager.getConnection(url, user, password);
            System.out.println("Connexion effective !");
            //Création d'un objet Statement
            Statement state = conn.createStatement();
//L'objet ResultSet contient le résultat de la requête SQL
            ResultSet result = state.executeQuery("SELECT * FROM student");
//On récupère les MetaData de la reponse a notre requêtes.
            ResultSetMetaData resultMeta = result.getMetaData();
            System.out.println("\n**********************************");
//On affiche le nom des colonnes
            for(int i = 1; i <= resultMeta.getColumnCount(); i++) {
                System.out.print("\t" + resultMeta.getColumnName(i).toUpperCase() + "\t *");
            }
            System.out.println("\n**********************************");
// on parcours le contenu de notre object result autant de fois qu'il y a d'élément
            while(result.next()){
                for(int i = 1; i <= resultMeta.getColumnCount(); i++)
                    System.out.print("\t" + result.getObject(i).toString() + "\t |");
                System.out.println("\n---------------------------------");
            }
            result.close();
            state.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}