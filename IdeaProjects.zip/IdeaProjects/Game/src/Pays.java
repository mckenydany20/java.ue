public class Pays {
    public String nom;
    public String nomCapitale;
    public Pays(String nom,String nomcapitale){
        this.nom =nom;
        this.nomCapitale=nomcapitale;
    }
}
