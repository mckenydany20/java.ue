public class ListesPays {
    Pays[] liste  = new Pays[]{
            new Pays("south-africa","johannesburg")
            ,new Pays("monaco","monaco")
            ,new Pays("cameroon","yaounde")
            ,new Pays("Germany","berlin")
            ,new Pays("belgium","Bruxelles")
            ,new Pays("france","paris")
            ,new Pays("senegal","dakar")
            ,new Pays("ivory-cost","yamousoucrou")
            ,new Pays("russia","moscow")
            ,new Pays("united-states","new-york")
            ,new Pays("china","pekin")
            ,new Pays("england","london")
            ,new Pays("gabon","libreville")
            ,new Pays("mexique","mexico")
            ,new Pays("italie","vatican")
            ,new Pays("Bresil","rio de janero")
            ,new Pays("japon","tokyo")} ;


}