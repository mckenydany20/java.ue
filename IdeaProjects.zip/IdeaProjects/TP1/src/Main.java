import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.io.*;

public class Main {
    public static void main(String args[])throws IOException {
        String fichier;
        try {
            Scanner saisie = new Scanner(System.in);
            System.out.print("donner le nom du fichier");
            fichier = saisie.nextLine();
            PrintWriter sortie = new PrintWriter(new FileWriter(fichier));
            System.out.println("Salut et Bienvenue cher utilisateur s'il vous plait veuillez entrer votre nom !");
            String name = saisie.nextLine();
            sortie.println(name);
            String date = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss ").format(Calendar.getInstance().getTime());
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(fichier));
            sortie.println(date);

            System.out.print("quel est votre passe temps favoris entre\n 1-manger entre amis\n 2-dormir\n 3-faire des recherches\n");
            int reponse = saisie.nextInt();
            System.out.print("que preferez vous entre \n 1-amitie\n 2-solitude \n 3-argent");
            int reponse1 = saisie.nextInt();
            System.out.print("selon vous en quelque ligne a quoi se resume votre vie \n 1-prendre du bon temps avec ma famille et mes amis\n 2-restez dans son coin et faire sa vie\n 3-se battre et reussir\n");
            int reponse2 = saisie.nextInt();
            if (reponse == 1 && reponse1 == 1 && reponse2 == 1) {
                sortie.println(name + " vous avez une personnalite extravertis et sociale");
            } else if (reponse == 2 && reponse1 == 2 && reponse2 == 2) {
                sortie.println(name + " vous avez une personnalite introvertis et timide");
            } else if (reponse == 3 && reponse1 == 3 && reponse2 == 3) {
                sortie.println(name + " vous avez une personnalite extravertis et sociale");
            }else{
                System.out.println("desole" +name+ " nous ne parvenons pas a cerner votre personnalite");
            }
            String date1 = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss ").format(Calendar.getInstance().getTime());
            sortie.write(date1);
            sortie.close();
            sortie.println("fin de creation");
        } catch(InputMismatchException e) {
            System.out.println("desole  nous ne parvenons pas a cerner votre personnalite");
            System.out.println("erreur!!! exeption !");
        }
    }
}