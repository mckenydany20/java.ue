import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //System.out.println("svp entrer le nombre de caractere a saisir");
        Scanner saisie = new Scanner(System.in);
       // int n= saisie.nextInt();
        System.out.println("svp entrer vos caracteres");
        for (int i=0;i<=2;i++) {
            String caractere = saisie.nextLine();
        }

        System.out.println("aaa,aab,aba,baa,aac,aca,caa,bbb,bba,bab,abb,bbc,bcb,cbb,cc,"+
                "cca,cac,acc,ccb,cbc,bcc");
    }
}