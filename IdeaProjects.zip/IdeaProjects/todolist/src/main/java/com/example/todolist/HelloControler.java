package com.example.todolist;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.ResourceBundle;

public class HelloControler implements Initializable {
    public TextArea nom;
    public TextArea description;
    public TextArea detnom;
    public TableColumn<User,String> tabnom = new TableColumn<>("Noms");
    public TableColumn<User,String> tabdescription=new TableColumn<>("Description");
    public TableView<User> table;

    ObservableList<User> data = FXCollections.observableArrayList();
    public void validate(ActionEvent actionEvent) {

    }

    public void Nosend(ActionEvent actionEvent) {
    }

    public void send(ActionEvent actionEvent) {
        User doo = new User("donald","dhuvfgwuy");
        data.setAll(doo);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        tabnom.setCellValueFactory(new PropertyValueFactory<User,String>("nom"));
        tabdescription.setCellValueFactory(new PropertyValueFactory<User,String>("description"));



        table.setItems(data);
    }
}
