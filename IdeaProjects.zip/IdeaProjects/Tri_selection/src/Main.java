import java.util.Scanner;
public class Main{
    public static void tri_selection_croissant(double[] tab)
    {
        for (int i = 0; i < tab.length - 1; i++)
        {
            int index = i;
            for (int j = i + 1; j < tab.length; j++)
            {
                if (tab[j] < tab[index]){
                    index = j;
                }
            }
            double min = tab[index];
            tab[index] = tab[i];
            tab[i] = min;
        }
    }
    public static void tri_selection_decroissant(double[] tab)
    {
        for (int i = 0; i < tab.length - 1; i++)
        {
            int index = i;
            for (int j = i + 1; j < tab.length; j++)
            {
                if (tab[j] > tab[index]){
                    index = j;
                }
            }
            double min = tab[index];
            tab[index] = tab[i];
            tab[i] = min;
        }
    }
    public static void recherche(double a,double[] tab){
        for (int i=0;i<tab.length;i++){
            if(a==tab[i]){
                System.out.println("la valeur " +a+" se trouve a l'index " +i+" du tableau");
            }
        }
    }
    static void affichetab(double[] tab){
        for(int i=0; i < tab.length; i++)
        {
            System.out.print(tab[i] + " ");
        }
        System.out.println();
    }

    public static void main(String args[])
    {
        double[] tab= new double[args.length];
        for(int i=0;i<args.length;i++){
            tab[i]=Double.valueOf(args[i]);
        }
        Scanner saisie=new Scanner(System.in);
        System.out.println("Avant le tri par selection ");
        affichetab(tab);
        tri_selection_croissant(tab);
        System.out.println("Apres le tri par selection croissant");
        affichetab(tab);
        tri_selection_decroissant(tab);
        System.out.println("Apres le tri par selection decroissant");
        affichetab(tab);
        System.out.println("quel nombre chercher vous?");
        double a= saisie.nextDouble();
        System.out.println("Dans le tableau decroissant");
        recherche(a,tab);
        tri_selection_croissant(tab);
        System.out.println("Dans le tableau croissant");
        recherche(a,tab);
    }
}
