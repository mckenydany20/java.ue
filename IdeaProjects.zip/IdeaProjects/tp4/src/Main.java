class Point{
    private int x;
    private int y;
    public Point(int x, int y){
        this.x = x;
        this.y = y;
    }
    public void initailiser(int x,int y){
        this.x = x;
        this.y = y;
    }
    public void deplacer(int dy, int dx){
        x += dx;
        y +=dy;
    }
    public void afficher(){
        System.out.println("Je suis un point de coordonnees "+x+" et "+y);
    }
}
public class Main {
    public static void main(String[] args) {
        Point pt1 = new Point(4,8);
        pt1.initailiser(4,6);
        pt1.afficher();
        pt1.deplacer(2,3);
        pt1.afficher();

    }
}