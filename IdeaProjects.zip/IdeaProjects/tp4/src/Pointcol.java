public class Pointcol extends Point{
    byte couleur;

    public Pointcol(int x, int y, byte couleur) {
        super(x, y);
        this.couleur = couleur;
    }
    public void colorer(byte couleur){
        this.couleur = couleur;
    }
    public void afficher(){
        super.afficher();
        System.out.println(" et de couleur "+couleur);
    }

    public static void main(String[] args) {
        Pointcol pt1 = new Pointcol(4,6, (byte) -10);
        pt1.afficher();
        pt1.colorer((byte) 30);
        pt1.afficher();
    }
}

