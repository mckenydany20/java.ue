import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        System.out.println("how are you?");
        Scanner clavier= new Scanner(System.in);
        String saisie= clavier.nextLine();
        int age = clavier.nextInt();
        System.out.println("votre nom est "+saisie+ " votre age est "+age);

    }
}