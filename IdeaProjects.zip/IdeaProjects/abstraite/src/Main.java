abstract class Animal{
    abstract void crier();
}
class Chien extends Animal{
    void crier(){
        System.out.println("je suis un chien");
    }
}
public class Main {
    public static void main(String[] args) {
        Animal chat=new Animal() {
            @Override
            void crier() {
                System.out.println("je suis un chat");
            }
        };
        chat.crier();
        Chien chien=new Chien();
        chien.crier();

    }
}