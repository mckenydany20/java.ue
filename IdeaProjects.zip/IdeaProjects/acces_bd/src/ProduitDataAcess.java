import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ProduitDataAcess {
    /*
    * se connecter a la base de donnee
    * chaine de connexion
    * nom de la base de donnes
    * nom d'utilisateur
    * mot de passe
    * */
    String db="magasin_db";
    String user="root";
    String password="";
    String url="jdbc:mysql://localhost:3306/"+db;
    public ProduitDataAcess() {
        try {
            Connection connection = DriverManager.getConnection(url, user, password);
            System.out.println("connected...");
        }catch (SQLException e){
            e.printStackTrace();
        }
    }
}







