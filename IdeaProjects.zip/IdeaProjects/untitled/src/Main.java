import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner saisie = new Scanner(System.in);
        System.out.println("entrer votre nombre d'etudiant que vous voulez enregistrer");
        int n = saisie.nextInt();
        Etudiant tab[] = new Etudiant[n];
        for (int i = 0; i < n; i++) {
            System.out.println("Entrez le matricule de l'etudiant");
            saisie.next();
            String mat = saisie.nextLine();
            System.out.println("Entrez le nom de l'etudiant ");
            String nom = saisie.nextLine();
            System.out.println("Entrez le genre de l'etudiant");
            String genre = saisie.nextLine();
            System.out.println("Entrez la date de naissance de l'etudiant au format yyyy/mm/dd");
            String date = saisie.nextLine();
            System.out.println("Entrez la moyenne de l'etudiant");
            float Moyenne = saisie.nextFloat();
            tab[i] = new Etudiant(mat, nom, date, genre, Moyenne);
        }
        triInsertion(tab);
        boolean varboucle = true;

        System.out.println("Que voulez vous faire ?");
        System.out.println("1- Afficher les etudiants par ordre de merite\n2- Afficher les informaion du premier etudiant\n3-Afficher les informaion du dernier etudiant\n4- Reinitialise la liste des etudiants\n5- Sortir du programme");
        int choix = saisie.nextInt();

        switch (choix) {
            case 1:

                System.out.println(" Matricule\t Nom\t Date de Naissance\t Genre\t Moyenne\t ");
                for (int k = 0; k < tab.length; k++) {
                    System.out.print(k + 1 + "-\t");
                    tab[k].afficher();
                }
                for (int k = 0; k < tab.length; k++) {
                    System.out.print("la moyenne de l'etudiant " + (k + 1) + " est : ");
                    tab[k].getMoyenne();
                    System.out.println(tab[k].getMoyenne());

                }

                break;
            case 2:
                System.out.println("Numero\t Nom\t Matricule\t Date de Naissance\t Genre\t Moyenne\t ");
                System.out.print(1 + "-\t");
                tab[0].afficher();
                break;
            case 3:
                System.out.println("Numero\t Nom\t Matricule\t Date de Naissance\t Genre\t Moyenne\t ");
                System.out.print(n + "-\t");
                tab[n - 1].afficher();
                break;
            case 4:
                break;
            case 5:
                varboucle = false;//On quitte tout simplement la boucle
                break;
            default:
                System.out.println("Desole nous ne traitons pas ce cas nous y travaillons");
                break;
        }

    }
    public static void triInsertion(Etudiant T[])
    {
        int i,j;
        Etudiant save;
        for(i=1;i<T.length;i++)
        {
            save=T[i];
            j=i;
            while(j>=1 && T[j-1].getMoyenne()<save.getMoyenne())
            {
                T[j]=T[j-1];
                j=j-1;
            }
            T[j]=save;
        }
    }
}