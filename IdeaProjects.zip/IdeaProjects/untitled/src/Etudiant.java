import java.util.Scanner;
public class Etudiant {
    //Scanner entree1 = new Scanner(System.in);
    private String matricule, nom, genre, dateNaissance;
    private float Moyenne;
    private final int N= 2020;
    public Etudiant(String mat, String nom, String date, String genre,float Moyenne)
    {
        this.matricule = mat;
        this.nom = nom;
        this.dateNaissance = date;
        this.genre = genre;
        this.Moyenne=Moyenne;

    }

    public void afficher()
    {
        String information = this.nom+"\t     "+this.matricule+"\t    "+this.dateNaissance+"\t  "+this.genre+"\t    "+this.Moyenne;
        System.out.println(information);
    }
    public void bonifier(double b){
        this.Moyenne+= b;
    }
    public float getMoyenne(){
        return this.Moyenne;
    }

}
