import java.util.Arrays;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        System.out.println("\t\tBienvenue dans votre gestionnaire de donnees(Statistique");
        int i, j, k;
        float s = 0;
        Scanner saisie = new Scanner(System.in);
        System.out.println("\nentrer la taille ou le nombre de vos modalites et effectifs");
        int n = saisie.nextInt();
        String[] modalites = new String[n];
        float[] frequence = new float[n];
        float[] effectif = new float[n];
        for (i = 0; i < n; i++) {
            System.out.println("\tveuillez entrer la modalite d'indice " + i);
            modalites[i] = saisie.next();
        }
        for (j = 0; j < n; j++) {
            System.out.println("\tentrer l'effectif d'indice " + j);
            effectif[j] = saisie.nextInt();
            s = s + effectif[j];
        }
        for (k = 0; k < n; k++) {
            frequence[k] = (effectif[k] / s) * 100;
        }
        System.out.println("\t\tle nombre de modalite est " + n);
        System.out.println("\t\tles modalites sont " + Arrays.toString(modalites));
        System.out.println("\t\tles effectifs sont " + Arrays.toString(effectif));
        System.out.println("\t\tl'effectif total est " + s);
        float moy = s / n;
        System.out.println("\n\tla moyenne de cette serie est " + moy);
        System.out.println("\t\tles frequences en pourcentage sont " + Arrays.toString(frequence));
        float index;
        for(i=1;i<effectif.length;i++)
        {
            index=effectif[i];
            j=i;
            while(j>=1 && effectif[j-1]<index)
            {
                effectif[j]=effectif[j-1];
                j=j-1;
            }
            effectif[j]=index;
        }
        System.out.println("\tla plus grande modalite est celle qui a l'effectif " +effectif[0]);
        System.out.println("\tla plus petite modalite est celle qui a l'effectif " +effectif[n-1]);
        float variance,ecart;
        float[] var = new float[n];
        float v=0;
        for(i=1;i<effectif.length;i++){
           var[i]= (float) Math.pow((effectif[i]-moy),2);
           v=v+var[i];
       }
        variance= (float) Math.sqrt((v/(s-1)));
        System.out.println("\tla variance de cette serie statisque est "+variance);
        ecart=(float) Math.sqrt(variance);
        System.out.println("\tl'ecart type de cette serie statistique est "+ecart);
    }
}