import java.util.Scanner;
public class Main {
    public static void main(String args[]) throws java.io.IOException {
        System.out.println();
        int choix;
        double a, b, c, delta, x,x1, x2;
        System.out.println("Bienvenue dans le resolveur d'équations JAVA");
        System.out.println("selectionner le degre de votre equation\n 1-premier degre\n 2-second degre");
        Scanner saisie = new Scanner(System.in);
        choix=saisie.nextInt();
        switch (choix){
            case 1:
                System.out.println("entrer vos valeurs tels que ax+b=c");

                System.out.println("a = ");
                a = saisie.nextDouble();
                System.out.println("b = ");
                b = saisie.nextDouble();
                System.out.println("c = ");
                c = saisie.nextDouble();
                if(c==0){
                    x=-b/a;
                    System.out.println("la solution de l'equation est "+x);
                }else{
                    x=(c-b)/a;
                    System.out.println("la solution de l'equation est "+x);
                }
            case 2:
                System.out.println("Entrez les valeurs de a,b,c tel que ax²+bx+c");

                System.out.println("a = ");
                a = saisie.nextDouble();
                System.out.println("b = ");
                b = saisie.nextDouble();
                System.out.println("c = ");
                c = saisie.nextDouble();

                delta = (b * b) - 4 * a * c;
                if (delta < 0) {
                    System.out.println("\nIl n'y a pas de racines reelle a l'equation.");
                } else if (delta == 0) {
                    x1 = -b / (2 * a);
                    System.out.println("\n la solution admet une solution double qui est " + x1);
                } else {
                    x1 = (-b - Math.sqrt(delta)) / (2 * a);
                    x2 = (-b + Math.sqrt(delta)) / (2 * a);
                    System.out.println("\nLes racines sont x1 = " + x1 + " et x2 = " + x2);
                }
        }

    }
}